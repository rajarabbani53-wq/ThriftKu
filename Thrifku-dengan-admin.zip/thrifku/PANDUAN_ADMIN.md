# Panduan Admin Panel ThriftKu

## Yang baru ditambahkan
- Login admin terpisah dari user (`/admin/login`)
- CRUD produk (tambah, edit, hapus) di `/admin/produk`
- Kelola pesanan — konfirmasi / batalkan (stok otomatis kembali saat dibatalkan) di `/admin/pesanan`
- Kelola pelanggan (lihat & hapus) di `/admin/pelanggan`
- Dashboard ringkasan toko di `/admin`

## Cara menjalankan

```bash
composer install
cp .env.example .env   # jika belum ada .env
php artisan key:generate
php artisan migrate
php artisan db:seed
php artisan storage:link
npm install && npm run build
php artisan serve
```

## Login admin default
Setelah `php artisan db:seed`, gunakan:
- **Username:** `admin`
- **Password:** `admin123`

Akses di: `http://localhost:8000/admin/login`

**Penting:** segera ganti password admin default ini sebelum dipakai di production (belum ada halaman ganti password — bisa update manual lewat `php artisan tinker`):
```php
$a = App\Models\Admin::where('username', 'admin')->first();
$a->password = 'password_baru_anda';
$a->save();
```

## Struktur tabel baru
- `admin` — akun admin
- `pelanggan` — akun pelanggan (terpisah dari tabel `users` bawaan Laravel)
- `keranjang` — isi keranjang belanja per pelanggan
- `pesanan` — data pesanan (status: Pending / Terkonfirmasi / Dibatalkan)
- `detail_pesanan` — rincian item per pesanan

## Catatan
- Folder `resources/admin/*.html` (statis lama) sudah dihapus, digantikan penuh oleh Blade view di `resources/views/admin/`.
- Alur checkout (`database/proses_checkout.php` dkk.) yang lama menggunakan PHP native/mysqli — ini **belum** dihubungkan ke Laravel. Jika ingin, saya bisa bantu buatkan `CheckoutController` di sisi user agar konsisten pakai Eloquent seperti bagian admin.
- Upload gambar produk otomatis tersimpan ke `storage/app/public/produk` dan tampil via `php artisan storage:link`.
