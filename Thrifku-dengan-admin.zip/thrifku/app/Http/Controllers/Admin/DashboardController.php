<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pelanggan;
use App\Models\Pesanan;
use App\Models\Produk;

class DashboardController extends Controller
{
    public function index()
    {
        $totalProduk = Produk::count();
        $pesananBaru = Pesanan::where('status_pesanan', 'Pending')->count();
        $pendapatanBulanIni = Pesanan::where('status_pesanan', 'Terkonfirmasi')
            ->whereMonth('created_at', now()->month)
            ->whereYear('created_at', now()->year)
            ->sum('total_harga');
        $totalPelanggan = Pelanggan::count();

        $pesananTerbaru = Pesanan::with('pelanggan')
            ->latest()
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'totalProduk',
            'pesananBaru',
            'pendapatanBulanIni',
            'totalPelanggan',
            'pesananTerbaru'
        ));
    }
}
