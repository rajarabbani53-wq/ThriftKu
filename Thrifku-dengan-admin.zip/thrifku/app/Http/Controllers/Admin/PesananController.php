<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pesanan;
use App\Models\Produk;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PesananController extends Controller
{
    public function index(Request $request)
    {
        $query = Pesanan::with(['pelanggan', 'detail.produk']);

        if ($request->filled('status')) {
            $query->where('status_pesanan', $request->status);
        }

        $pesanan = $query->latest('id_pesanan')->paginate(10)->withQueryString();

        return view('admin.pesanan.index', compact('pesanan'));
    }

    public function konfirmasi(Pesanan $pesanan)
    {
        $pesanan->update(['status_pesanan' => 'Terkonfirmasi']);

        return back()->with('sukses', 'Pesanan #' . $pesanan->id_pesanan . ' berhasil dikonfirmasi.');
    }

    public function batalkan(Request $request, Pesanan $pesanan)
    {
        $request->validate([
            'alasan_pembatalan' => 'required|string|max:255',
        ]);

        DB::transaction(function () use ($request, $pesanan) {
            $pesanan->update([
                'status_pesanan' => 'Dibatalkan',
                'alasan_pembatalan' => $request->alasan_pembatalan,
            ]);

            foreach ($pesanan->detail as $item) {
                Produk::where('id_produk', $item->id_produk)->increment('stok', $item->kuantitas);
            }
        });

        return back()->with('sukses', 'Pesanan #' . $pesanan->id_pesanan . ' berhasil dibatalkan.');
    }
}
