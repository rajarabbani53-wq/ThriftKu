<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Admin;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Seeder bawaan untuk User
        User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);

        // Akun admin default untuk login ke /admin
        Admin::firstOrCreate(
            ['username' => 'admin'],
            [
                'nama' => 'Admin ThriftKu',
                'password' => 'admin123', // otomatis di-hash oleh cast 'hashed' pada model Admin
            ]
        );

        // --- KODE SEEDER PRODUK YANG SUDAH DIPERBAIKI SINTAKS-NYA ---
        DB::table('produk')->insert([
    [
        'nama_produk' => 'Kemeja Flannel Vintage',
        'kategori' => 'Baju',
        'harga' => 85000,
        'ukuran' => 'L',
        'gambar' => 'flannel.jpg',
        'stok' => 1, // <--- Tambahkan ini
    ],
    [
        'nama_produk' => "Celana Levi's 501 Original",
        'kategori' => 'Celana',
        'harga' => 15000,
        'ukuran' => '32',
        'gambar' => 'levis.jpg',
        'stok' => 1, // <--- Tambahkan ini
    ],
    [
        'nama_produk' => 'Kaos Oversize Nike',
        'kategori' => 'Baju',
        'harga' => 65000,
        'ukuran' => 'XL',
        'gambar' => 'nike.jpg',
        'stok' => 1, // <--- Tambahkan ini
    ]
]);
    }
}