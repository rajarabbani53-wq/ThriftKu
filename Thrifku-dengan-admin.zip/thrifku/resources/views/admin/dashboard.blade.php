@extends('admin.layouts.app')

@section('title', 'Dashboard')
@section('subtitle', 'Ringkasan toko - update terakhir hari ini')

@section('content')

<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px;">
    <div class="stat-card">
        <p class="stat-label">Total produk</p>
        <p class="stat-value">{{ $totalProduk }}</p>
    </div>
    <div class="stat-card">
        <p class="stat-label">Pesanan baru</p>
        <p class="stat-value">{{ $pesananBaru }}</p>
    </div>
    <div class="stat-card">
        <p class="stat-label">Pendapatan bulan ini</p>
        <p class="stat-value">Rp {{ number_format($pendapatanBulanIni, 0, ',', '.') }}</p>
    </div>
    <div class="stat-card">
        <p class="stat-label">Pelanggan terdaftar</p>
        <p class="stat-value">{{ $totalPelanggan }}</p>
    </div>
</div>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
        <h3 style="font-size: 14px; font-weight: 600; margin: 0;">Pesanan terbaru</h3>
        <a href="{{ route('admin.pesanan.index') }}" class="btn btn-sm">Lihat semua</a>
    </div>

    @if ($pesananTerbaru->isEmpty())
        <div class="empty-state">Belum ada pesanan masuk.</div>
    @else
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Pelanggan</th>
                    <th>Total</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pesananTerbaru as $p)
                    <tr>
                        <td>#TK-{{ str_pad($p->id_pesanan, 3, '0', STR_PAD_LEFT) }}</td>
                        <td>{{ $p->pelanggan->nama ?? '-' }}</td>
                        <td>Rp {{ number_format($p->total_harga, 0, ',', '.') }}</td>
                        <td>
                            @if ($p->status_pesanan == 'Terkonfirmasi')
                                <span class="badge badge-confirmed">Terkonfirmasi</span>
                            @elseif ($p->status_pesanan == 'Dibatalkan')
                                <span class="badge badge-cancelled">Dibatalkan</span>
                            @else
                                <span class="badge badge-pending">Pending</span>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>

@endsection
