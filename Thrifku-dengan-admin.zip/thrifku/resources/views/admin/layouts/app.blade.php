<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dashboard') - ThriftKu Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.44.0/tabler-icons.min.css">
    <style>
        :root {
            --sage: #506049;
            --sage-dark: #3c4b35;
            --bg-page: #f6f5f2;
            --bg-card: #ffffff;
            --border: #e4e2e1;
            --text-primary: #1b1c1c;
            --text-secondary: #6b6d67;
            --text-muted: #9a9c96;
            --success-bg: #e7f3e8; --success-text: #2f6b34; --success-border: #bfe0c2;
            --warning-bg: #fdf3df; --warning-text: #9a6b0c; --warning-border: #f2dca6;
            --danger-bg: #fbe9e7; --danger-text: #a13b2e; --danger-border: #f0c6bd;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: var(--bg-page);
            color: var(--text-primary);
        }
        .admin-shell { display: flex; min-height: 100vh; }
        .sidebar {
            width: 220px;
            background: var(--bg-card);
            border-right: 1px solid var(--border);
            padding: 20px 0;
            flex-shrink: 0;
        }
        .sidebar-brand {
            font-size: 18px;
            font-weight: 600;
            padding: 0 20px 20px;
        }
        .sidebar-brand span {
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 400;
            margin-left: 4px;
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 2px; }
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 20px;
            font-size: 14px;
            color: var(--text-secondary);
            text-decoration: none;
            border-left: 3px solid transparent;
        }
        .sidebar-link:hover { background: #f6f5f2; color: var(--text-primary); }
        .sidebar-link.active {
            background: #eef2ec;
            color: var(--sage);
            font-weight: 600;
            border-left-color: var(--sage);
        }
        .sidebar-link i { font-size: 18px; }
        .main-area { flex: 1; padding: 24px 32px; max-width: calc(100vw - 220px); }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .topbar h1 { font-size: 20px; font-weight: 600; margin: 0 0 2px; }
        .topbar p { font-size: 12px; color: var(--text-secondary); margin: 0; }
        .topbar-admin { font-size: 13px; color: var(--text-secondary); }

        .card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 16px; }
        .stat-card { background: #fbfaf8; border-radius: 10px; padding: 14px 16px; }
        .stat-label { font-size: 12px; color: var(--text-secondary); margin: 0 0 4px; }
        .stat-value { font-size: 22px; font-weight: 600; margin: 0; }

        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        thead th { text-align: left; color: var(--text-secondary); font-weight: 500; padding: 10px 8px; border-bottom: 1px solid var(--border); }
        tbody td { padding: 10px 8px; border-bottom: 1px solid var(--border); vertical-align: middle; }
        tbody tr:last-child td { border-bottom: none; }

        .badge { display: inline-block; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 999px; text-transform: capitalize; }
        .badge-pending { background: var(--warning-bg); color: var(--warning-text); border: 1px solid var(--warning-border); }
        .badge-confirmed { background: var(--success-bg); color: var(--success-text); border: 1px solid var(--success-border); }
        .badge-cancelled { background: #f1f0ec; color: var(--text-secondary); border: 1px solid var(--border); }

        .btn { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; padding: 8px 16px; border-radius: 8px; border: 1px solid var(--border); background: white; color: var(--text-primary); cursor: pointer; text-decoration: none; }
        .btn:hover { background: #f6f5f2; }
        .btn-primary { background: var(--sage); border-color: var(--sage); color: white; }
        .btn-primary:hover { background: var(--sage-dark); }
        .btn-danger { color: var(--danger-text); border-color: var(--danger-border); background: var(--danger-bg); }
        .btn-danger:hover { background: #f6d9d3; }
        .btn-sm { padding: 5px 12px; font-size: 12px; }

        input[type=text], input[type=search], input[type=number], input[type=password], select, textarea {
            width: 100%;
            padding: 9px 12px;
            border-radius: 8px;
            border: 1px solid var(--border);
            font-size: 13px;
            font-family: inherit;
            background: #fbfaf8;
        }
        input:focus, select:focus, textarea:focus { outline: none; border-color: var(--sage); background: white; }
        label { font-size: 12px; font-weight: 600; color: var(--text-secondary); display: block; margin-bottom: 6px; }

        .alert-success { background: var(--success-bg); color: var(--success-text); border: 1px solid var(--success-border); padding: 10px 16px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; }
        .alert-error { background: var(--danger-bg); color: var(--danger-text); border: 1px solid var(--danger-border); padding: 10px 16px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; }

        .empty-state { text-align: center; padding: 40px 20px; color: var(--text-secondary); font-size: 13px; }
    </style>
</head>
<body>

<div class="admin-shell">
    <aside class="sidebar">
        <div class="sidebar-brand">ThriftKu <span>admin</span></div>
        <nav class="sidebar-nav">
            <a href="{{ route('admin.dashboard') }}" class="sidebar-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                <i class="ti ti-layout-dashboard"></i> Dashboard
            </a>
            <a href="{{ route('admin.produk.index') }}" class="sidebar-link {{ request()->routeIs('admin.produk.*') ? 'active' : '' }}">
                <i class="ti ti-package"></i> Produk
            </a>
            <a href="{{ route('admin.pesanan.index') }}" class="sidebar-link {{ request()->routeIs('admin.pesanan.*') ? 'active' : '' }}">
                <i class="ti ti-shopping-bag"></i> Pesanan
            </a>
            <a href="{{ route('admin.pelanggan.index') }}" class="sidebar-link {{ request()->routeIs('admin.pelanggan.*') ? 'active' : '' }}">
                <i class="ti ti-users"></i> Pelanggan
            </a>
            <form action="{{ route('admin.logout') }}" method="POST" style="margin-top: 8px; border-top: 1px solid var(--border); padding-top: 8px;">
                @csrf
                <button type="submit" class="sidebar-link" style="border: none; background: none; width: 100%; text-align: left; cursor: pointer; font: inherit;">
                    <i class="ti ti-logout"></i> Keluar
                </button>
            </form>
        </nav>
    </aside>

    <main class="main-area">
        <div class="topbar">
            <div>
                <h1>@yield('title', 'Dashboard')</h1>
                <p>@yield('subtitle', 'Kelola toko ThriftKu Anda')</p>
            </div>
            <div class="topbar-admin">
                <i class="ti ti-user-circle"></i> {{ session('admin_nama', 'Admin') }}
            </div>
        </div>

        @if (session('sukses'))
            <div class="alert-success">{{ session('sukses') }}</div>
        @endif
        @if ($errors->any())
            <div class="alert-error">{{ $errors->first() }}</div>
        @endif

        @yield('content')
    </main>
</div>

</body>
</html>
