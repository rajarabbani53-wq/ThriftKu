<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - ThriftKu</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f6f5f2;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .login-card {
            background: #ffffff;
            border: 1px solid #e4e2e1;
            border-radius: 14px;
            padding: 40px 36px;
            width: 100%;
            max-width: 380px;
        }
        .brand { font-size: 22px; font-weight: 700; color: #506049; margin-bottom: 4px; text-align: center; }
        .subtitle { font-size: 13px; color: #6b6d67; text-align: center; margin-bottom: 28px; }
        label { font-size: 12px; font-weight: 600; color: #6b6d67; display: block; margin-bottom: 6px; }
        input {
            width: 100%;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid #e4e2e1;
            font-size: 13px;
            margin-bottom: 16px;
            background: #fbfaf8;
        }
        input:focus { outline: none; border-color: #506049; background: white; }
        button {
            width: 100%;
            padding: 11px;
            border-radius: 999px;
            border: none;
            background: #506049;
            color: white;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
        }
        button:hover { background: #3c4b35; }
        .alert-error { background: #fbe9e7; color: #a13b2e; border: 1px solid #f0c6bd; padding: 10px 14px; border-radius: 8px; font-size: 12px; margin-bottom: 16px; }
        .back-link { display: block; text-align: center; margin-top: 20px; font-size: 12px; color: #6b6d67; text-decoration: none; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="brand">ThriftKu</div>
    <div class="subtitle">Panel administrasi toko</div>

    @if ($errors->any())
        <div class="alert-error">{{ $errors->first() }}</div>
    @endif

    <form action="{{ route('admin.login.submit') }}" method="POST">
        @csrf
        <label for="username">Username</label>
        <input type="text" id="username" name="username" value="{{ old('username') }}" placeholder="admin" required autofocus>

        <label for="password">Kata sandi</label>
        <input type="password" id="password" name="password" placeholder="********" required>

        <button type="submit">Masuk ke Dashboard</button>
    </form>

    <a href="/" class="back-link">&larr; Kembali ke toko</a>
</div>

</body>
</html>
