@extends('admin.layouts.app')

@section('title', 'Pelanggan')
@section('subtitle', 'Data pelanggan yang terdaftar di ThriftKu')

@section('content')

<form method="GET" style="margin-bottom: 16px; max-width: 320px;">
    <input type="search" name="cari" value="{{ request('cari') }}" placeholder="Cari nama atau email...">
</form>

<div class="card">
    @if ($pelanggan->isEmpty())
        <div class="empty-state">Belum ada pelanggan terdaftar.</div>
    @else
        <table>
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>No. HP</th>
                    <th>Total pesanan</th>
                    <th style="text-align: right;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pelanggan as $p)
                    <tr>
                        <td style="font-weight: 600;">{{ $p->nama }}</td>
                        <td>{{ $p->email }}</td>
                        <td>{{ $p->no_hp ?? '-' }}</td>
                        <td>{{ $p->pesanan_count }}</td>
                        <td style="text-align: right;">
                            <form action="{{ route('admin.pelanggan.destroy', $p->id_pelanggan) }}" method="POST" style="display: inline;" onsubmit="return confirm('Hapus pelanggan {{ $p->nama }}?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>

<div style="margin-top: 16px;">
    {{ $pelanggan->links() }}
</div>

@endsection
