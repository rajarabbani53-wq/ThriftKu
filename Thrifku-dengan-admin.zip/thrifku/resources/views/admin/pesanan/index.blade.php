@extends('admin.layouts.app')

@section('title', 'Pesanan')
@section('subtitle', 'Konfirmasi atau batalkan pesanan pelanggan')

@section('content')

<div style="display: flex; gap: 8px; margin-bottom: 16px;">
    <a href="{{ route('admin.pesanan.index') }}" class="btn btn-sm {{ !request('status') ? 'btn-primary' : '' }}">Semua</a>
    <a href="{{ route('admin.pesanan.index', ['status' => 'Pending']) }}" class="btn btn-sm {{ request('status') == 'Pending' ? 'btn-primary' : '' }}">Pending</a>
    <a href="{{ route('admin.pesanan.index', ['status' => 'Terkonfirmasi']) }}" class="btn btn-sm {{ request('status') == 'Terkonfirmasi' ? 'btn-primary' : '' }}">Terkonfirmasi</a>
    <a href="{{ route('admin.pesanan.index', ['status' => 'Dibatalkan']) }}" class="btn btn-sm {{ request('status') == 'Dibatalkan' ? 'btn-primary' : '' }}">Dibatalkan</a>
</div>

<div class="card">
    @if ($pesanan->isEmpty())
        <div class="empty-state">Tidak ada pesanan pada kategori ini.</div>
    @else
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Pelanggan</th>
                    <th>Pengiriman</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th style="text-align: right;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pesanan as $p)
                    <tr>
                        <td>#TK-{{ str_pad($p->id_pesanan, 3, '0', STR_PAD_LEFT) }}</td>
                        <td>{{ $p->pelanggan->nama ?? '-' }}</td>
                        <td>{{ $p->metode_pengiriman }}</td>
                        <td>Rp {{ number_format($p->total_harga, 0, ',', '.') }}</td>
                        <td>
                            @if ($p->status_pesanan == 'Terkonfirmasi')
                                <span class="badge badge-confirmed">Terkonfirmasi</span>
                            @elseif ($p->status_pesanan == 'Dibatalkan')
                                <span class="badge badge-cancelled">Dibatalkan</span>
                                @if ($p->alasan_pembatalan)
                                    <div style="font-size: 11px; color: #9a9c96; margin-top: 2px;">{{ $p->alasan_pembatalan }}</div>
                                @endif
                            @else
                                <span class="badge badge-pending">Pending</span>
                            @endif
                        </td>
                        <td style="text-align: right;">
                            @if ($p->status_pesanan == 'Pending')
                                <form action="{{ route('admin.pesanan.konfirmasi', $p->id_pesanan) }}" method="POST" style="display: inline;">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-primary">Konfirmasi</button>
                                </form>
                                <button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById('modal-batal-{{ $p->id_pesanan }}').style.display='flex'">Batalkan</button>

                                <div id="modal-batal-{{ $p->id_pesanan }}" style="display:none; position: fixed; inset: 0; background: rgba(0,0,0,0.4); align-items: center; justify-content: center; z-index: 50;">
                                    <div class="card" style="background: white; width: 100%; max-width: 380px; text-align: left;">
                                        <h3 style="font-size: 14px; margin: 0 0 12px;">Batalkan pesanan #TK-{{ str_pad($p->id_pesanan, 3, '0', STR_PAD_LEFT) }}</h3>
                                        <form action="{{ route('admin.pesanan.batalkan', $p->id_pesanan) }}" method="POST">
                                            @csrf
                                            <label>Alasan pembatalan</label>
                                            <textarea name="alasan_pembatalan" rows="3" placeholder="Stok habis, dll." required></textarea>
                                            <div style="display: flex; gap: 8px; margin-top: 12px;">
                                                <button type="submit" class="btn btn-danger">Ya, batalkan</button>
                                                <button type="button" class="btn" onclick="document.getElementById('modal-batal-{{ $p->id_pesanan }}').style.display='none'">Tutup</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            @else
                                <span style="font-size: 12px; color: #9a9c96;">-</span>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>

<div style="margin-top: 16px;">
    {{ $pesanan->links() }}
</div>

@endsection
