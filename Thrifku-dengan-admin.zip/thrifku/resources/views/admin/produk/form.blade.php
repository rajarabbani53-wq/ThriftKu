@extends('admin.layouts.app')

@section('title', $produk ? 'Edit produk' : 'Tambah produk')
@section('subtitle', $produk ? 'Perbarui informasi produk' : 'Tambahkan item baru ke katalog')

@section('content')

<div class="card" style="max-width: 560px;">
    <form action="{{ $produk ? route('admin.produk.update', $produk->id_produk) : route('admin.produk.store') }}"
          method="POST" enctype="multipart/form-data">
        @csrf
        @if ($produk)
            @method('PUT')
        @endif

        <div style="margin-bottom: 16px;">
            <label for="nama_produk">Nama produk</label>
            <input type="text" id="nama_produk" name="nama_produk" value="{{ old('nama_produk', $produk->nama_produk ?? '') }}" placeholder="Kemeja flanel vintage" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
            <div>
                <label for="harga">Harga (Rp)</label>
                <input type="number" id="harga" name="harga" value="{{ old('harga', $produk->harga ?? '') }}" placeholder="85000" min="0" required>
            </div>
            <div>
                <label for="stok">Stok</label>
                <input type="number" id="stok" name="stok" value="{{ old('stok', $produk->stok ?? 1) }}" min="0" required>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
            <div>
                <label for="kategori">Kategori</label>
                <select id="kategori" name="kategori" required>
                    @php $kategoriTerpilih = old('kategori', $produk->kategori ?? ''); @endphp
                    <option value="" disabled {{ $kategoriTerpilih == '' ? 'selected' : '' }}>Pilih kategori</option>
                    <option value="Baju" {{ $kategoriTerpilih == 'Baju' ? 'selected' : '' }}>Baju</option>
                    <option value="Celana" {{ $kategoriTerpilih == 'Celana' ? 'selected' : '' }}>Celana</option>
                    <option value="Wanita" {{ $kategoriTerpilih == 'Wanita' ? 'selected' : '' }}>Wanita</option>
                    <option value="Pria" {{ $kategoriTerpilih == 'Pria' ? 'selected' : '' }}>Pria</option>
                    <option value="Aksesoris" {{ $kategoriTerpilih == 'Aksesoris' ? 'selected' : '' }}>Aksesoris</option>
                </select>
            </div>
            <div>
                <label for="ukuran">Ukuran</label>
                <input type="text" id="ukuran" name="ukuran" value="{{ old('ukuran', $produk->ukuran ?? '') }}" placeholder="L / 32 / All Size" required>
            </div>
        </div>

        <div style="margin-bottom: 20px;">
            <label for="gambar">Foto produk</label>
            <input type="file" id="gambar" name="gambar" accept="image/*">
            @if ($produk && $produk->gambar)
                <div style="margin-top: 8px; font-size: 12px; color: #6b6d67;">Foto saat ini tersimpan. Unggah file baru untuk mengganti.</div>
            @endif
        </div>

        <div style="display: flex; gap: 8px;">
            <button type="submit" class="btn btn-primary">{{ $produk ? 'Simpan perubahan' : 'Tambah produk' }}</button>
            <a href="{{ route('admin.produk.index') }}" class="btn">Batal</a>
        </div>
    </form>
</div>

@endsection
