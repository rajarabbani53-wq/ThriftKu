@extends('admin.layouts.app')

@section('title', 'Produk')
@section('subtitle', 'Kelola katalog produk thrift Anda')

@section('content')

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; gap: 12px;">
    <form method="GET" style="flex: 1; max-width: 320px;">
        <input type="search" name="cari" value="{{ request('cari') }}" placeholder="Cari nama produk...">
    </form>
    <a href="{{ route('admin.produk.create') }}" class="btn btn-primary">
        <i class="ti ti-plus"></i> Tambah produk
    </a>
</div>

<div class="card">
    @if ($produk->isEmpty())
        <div class="empty-state">Belum ada produk. Klik "Tambah produk" untuk memulai.</div>
    @else
        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Kategori</th>
                    <th>Ukuran</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th style="text-align: right;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($produk as $item)
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 40px; height: 40px; border-radius: 6px; background: #f6f3f2; background-image: url('{{ $item->gambar ? asset('storage/' . $item->gambar) : '' }}'); background-size: cover; background-position: center; flex-shrink: 0;"></div>
                                <span style="font-weight: 600;">{{ $item->nama_produk }}</span>
                            </div>
                        </td>
                        <td>{{ $item->kategori }}</td>
                        <td>{{ $item->ukuran }}</td>
                        <td>Rp {{ number_format($item->harga, 0, ',', '.') }}</td>
                        <td>{{ $item->stok }}</td>
                        <td style="text-align: right;">
                            <a href="{{ route('admin.produk.edit', $item->id_produk) }}" class="btn btn-sm">Edit</a>
                            <form action="{{ route('admin.produk.destroy', $item->id_produk) }}" method="POST" style="display: inline;" onsubmit="return confirm('Hapus produk {{ $item->nama_produk }}?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>

<div style="margin-top: 16px;">
    {{ $produk->links() }}
</div>

@endsection
