<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja - ThriftKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { background-color: #fbf9f8; font-family: 'Inter', sans-serif; color: #1b1c1c; }
        h2, h4, .brand-title { font-family: 'Playfair Display', serif; }
        .card-custom { border: 1px solid #e4e2e1; border-radius: 12px; background-color: #ffffff; }
        .shipping-card { border: 1px solid #e4e2e1; border-radius: 8px; padding: 16px; margin-bottom: 12px; cursor: pointer; transition: 0.2s; }
        .shipping-card:hover { border-color: #506049; background-color: #f8ffef; }
        .btn-checkout { background-color: #506049; color: white; border-radius: 9999px; font-weight: 600; padding: 12px; width: 100%; border: none; }
        .btn-checkout:hover { background-color: #3c4b35; color: white; }
        .btn-continue { background-color: transparent; border: 1.5px solid #e4e2e1; color: #1b1c1c; border-radius: 9999px; font-weight: 600; padding: 12px; width: 100%; text-decoration: none; display: inline-block; text-align: center; margin-top: 8px; }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="mb-4">
        <h2 class="fw-bold m-0">Keranjang Belanja</h2>
        <p class="text-muted small">Pastikan pilihan Anda sebelum melakukan pembayaran.</p>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card-custom p-4 mb-4">
                <table class="table align-middle">
                    <thead class="text-muted small">
                        <tr>
                            <th>Produk</th>
                            <th>Ukuran</th>
                            <th class="text-center">Jumlah</th>
                            <th class="text-end">Harga</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <div style="width: 60px; height: 60px; background-color: #f6f3f2; border-radius: 6px;"></div>
                                    <div>
                                        <h6 class="fw-bold m-0">Sage Linen Oversized</h6>
                                        <small class="text-success" style="font-size:0.75rem;">Eco-Verified</small>
                                    </div>
                                </div>
                            </td>
                            <td>XL</td>
                            <td class="text-center">1</td>
                            <td class="text-end fw-bold">Rp 125.000</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <div style="width: 60px; height: 60px; background-color: #f6f3f2; border-radius: 6px;"></div>
                                    <div>
                                        <h6 class="fw-bold m-0">Classic Levi's 501</h6>
                                        <small class="text-warning" style="font-size:0.75rem;">Rare Vintage</small>
                                    </div>
                                </div>
                            </td>
                            <td>32</td>
                            <td class="text-center">1</td>
                            <td class="text-end fw-bold">Rp 250.000</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="row g-3">
                <div class="col-md-6">
                    <h5 class="fw-bold mb-3" style="font-size: 1rem;">🚚 Metode Pengiriman</h5>
                    <div class="shipping-card d-flex justify-content-between align-items-center">
                        <div>
                            <input type="radio" name="shipping" id="ambil" checked>
                            <label for="ambil" class="fw-bold ms-2">Ambil di Tempat</label>
                            <div class="small text-muted ms-4">Gratis • Lokasi Toko</div>
                        </div>
                    </div>
                    <div class="shipping-card d-flex justify-content-between align-items-center">
                        <div>
                            <input type="radio" name="shipping" id="antar">
                            <label for="antar" class="fw-bold ms-2">Diantar Admin</label>
                            <div class="small text-muted ms-4">Khusus Wilayah Kalimantan Barat</div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <h5 class="fw-bold mb-3" style="font-size: 1rem;">📍 Alamat Pengiriman</h5>
                    <div class="card-custom p-3">
                        <label class="small fw-bold text-muted mb-2">ALAMAT LENGKAP</label>
                        <textarea class="form-control" rows="3" style="font-size: 0.9rem;">Jl. Gajah Mada No. 12, Pontianak</textarea>
                        <small class="text-muted d-block mt-2" style="font-size: 0.75rem; font-style: italic;">*Pastikan alamat sudah sesuai untuk pengiriman Admin.</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card-custom p-4 shadow-sm position-sticky" style="top: 100px;">
                <h5 class="fw-bold mb-4">Ringkasan</h5>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Subtotal (2 Item)</span>
                    <span>Rp 375.000</span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Ongkos Kirim</span>
                    <span>Rp 0</span>
                </div>
                <div class="d-flex justify-content-between mb-4">
                    <span class="text-muted">Diskon</span>
                    <span>-Rp 0</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <span class="text-muted uppercase small fw-bold">TOTAL HARGA</span>
                    <h4 class="fw-bold text-success m-0">Rp 375.000</h4>
                </div>
                
                <button class="btn-checkout">Checkout / Buat Pesanan ➔</button>
                <a href="/" class="btn-continue">Lanjut Belanja</a>
                
                <div class="mt-4 p-3 rounded text-muted text-center" style="background-color: #f6f3f2; font-size: 0.8rem;">
                    🛡️ Transaksi Anda aman dan terenkripsi. Mendukung pembayaran via Transfer Bank & E-Wallet Lokal.
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>