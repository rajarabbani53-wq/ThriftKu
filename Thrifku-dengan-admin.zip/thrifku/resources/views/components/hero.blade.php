<!-- HERO SECTION DUAL-GENDER COLLECTION -->
<section class="thrift-hero-section">
    <div class="container-fluid h-100 p-0">
        <div class="row g-0 h-100">
            
            <!-- PANEL KIRI: KOLEKSI PRIA / UNISEX (Terinspirasi dari screen_8.jpg) -->
            <div class="col-md-6 hero-panel panel-men">
                <div class="panel-overlay"></div>
                <!-- Label Kategori -->
                <span class="collection-badge">Koleksi Pria & Unisex</span>
            </div>

            <!-- PANEL KANAN: KOLEKSI WANITA / BLAZER (Terinspirasi dari screen_7.jpg) -->
            <div class="col-md-6 hero-panel panel-women">
                <div class="panel-overlay"></div>
                <!-- Label Kategori -->
                <span class="collection-badge">Koleksi Wanita Eco-Verified</span>
            </div>

        </div>
    </div>

    <!-- KONTEN UTAMA & TOMBOL (Melayang di Tengah Sesuai image_d159a6.png) -->
    <div class="hero-floating-content text-center">
        <h1 class="hero-main-title font-serif">ThriftKu</h1>
        <p class="hero-sub-title">Sustainable Minimalism for Indonesian Fashion</p>
        
        <!-- Kombinasi Tombol Persis Seperti image_d159a6.png -->
        <div class="hero-btn-group d-flex justify-content-center gap-3 mt-4">
            <a href="/koleksi" class="btn-thrift-solid">Mulai Jelajah</a>
            <a href="/tentang-kami" class="btn-thrift-outline">Tentang Kami</a>
        </div>
    </div>
</section>

<!-- STYLESHEET KHUSUS HERO MINIMALIS -->
<style>
    .thrift-hero-section {
        position: relative;
        height: 85vh; /* Mengisi hampir seluruh tinggi layar browser */
        min-height: 550px;
        width: 100%;
        background-color: #fbf9f8;
        overflow: hidden;
    }

    /* Pengaturan Panel Gambar Berdampingan */
    .hero-panel {
        height: 100%;
        position: relative;
        background-size: cover;
        background-position: center;
        transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
    }

    /* Gambar Sisi Kiri - Pria/Unisex (Gaya Jaket Denim & Earth Tone) */
    .panel-men {
        background-image: url('https://c:\File Tugas 2025\Aplikasi TrifthKu\stitch_thriftku_e_commerce_ui_design\stitch_thriftku_e_commerce_ui_design\product_detail_mobile\screen.png');
    }

    /* Gambar Sisi Kanan - Wanita (Gaya Premium Wool Blazer dari screen_7.jpg) */
    .panel-women {
        background-image: url('https://c:\File Tugas 2025\Aplikasi TrifthKu\stitch_thriftku_e_commerce_ui_design\stitch_thriftku_e_commerce_ui_design\product_detail_desktop\screen.png');
    }

    /* Gelap Lembut (Overlay) agar teks di tengah tetap terbaca tajam */
    .panel-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(27, 28, 28, 0.35); /* Kegelapan seimbang */
        z-index: 1;
    }

    /* Label Kategori Pojok Bawah Halaman */
    .collection-badge {
        position: absolute;
        bottom: 35px;
        z-index: 3;
        color: #ffffff;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        background: rgba(27, 28, 28, 0.4);
        padding: 8px 18px;
        border-radius: 4px;
        backdrop-filter: blur(4px);
    }
    .panel-men .collection-badge { left: 40px; }
    .panel-women .collection-badge { right: 40px; }

    /* Konten Melayang di Tengah Grid */
    .hero-floating-content {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 10;
        width: 100%;
        max-width: 650px;
        padding: 0 20px;
        color: #ffffff;
    }

    .hero-main-title {
        font-size: 4.5rem;
        font-weight: 700;
        margin-bottom: 5px;
        letter-spacing: -0.02em;
        text-shadow: 0 4px 12px rgba(0,0,0,0.25);
    }

    .hero-sub-title {
        font-size: 1rem;
        font-weight: 400;
        letter-spacing: 0.05em;
        opacity: 0.95;
        text-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }

    /* --- TOMBOL IDENTIK DENGAN image_d159a6.png --- */
    
    /* Tombol Kiri: Hijau Sage Solid */
    .btn-thrift-solid {
        background-color: #4e5b47; /* Kode warna hijau sage asli ThriftKu */
        color: #ffffff !important;
        border: 2px solid #4e5b47;
        border-radius: 9999px; /* Bentuk pill/kapsul sempurna */
        padding: 12px 36px;
        font-weight: 600;
        font-size: 0.95rem;
        text-decoration: none;
        transition: all 0.2s ease;
        box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    }
    .btn-thrift-solid:hover {
        background-color: #3c4637;
        border-color: #3c4637;
        transform: translateY(-2px);
    }

    /* Tombol Kanan: Transparan Garis Putih */
    .btn-thrift-outline {
        background-color: transparent;
        color: #ffffff !important;
        border: 2px solid #ffffff; /* Outline putih bersih */
        border-radius: 9999px;
        padding: 12px 36px;
        font-weight: 600;
        font-size: 0.95rem;
        text-decoration: none;
        transition: all 0.2s ease;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .btn-thrift-outline:hover {
        background-color: #ffffff;
        color: #1b1c1c !important;
        transform: translateY(-2px);
    }

    /* Responsif untuk Smartphone */
    @media (max-width: 767px) {
        .thrift-hero-section { height: 70vh; }
        .hero-main-title { font-size: 3rem; }
        .hero-btn-group { flex-direction: column; gap: 12px !important; align-items: center; }
        .btn-thrift-solid, .btn-thrift-outline { width: 80%; text-align: center; padding: 10px 24px; }
        .panel-men, .panel-women { height: 50%; } /* Bertumpuk vertikal jika di HP */
    }
</style>