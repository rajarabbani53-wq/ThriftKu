<section class="py-12" style="background-color: #fbf9f8;">
    <div class="mx-auto max-w-6xl px-4 sm:px-6">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
                <h2 style="color: #1b1c1c; font-size: 2rem; font-family: ui-serif, Georgia, Cambria, serif;" class="font-semibold">
                    @if($kategoriAktif == 'Baju') Koleksi Baju 
                    @elseif($kategoriAktif == 'Celana') Koleksi Celana
                    @else Koleksi Terbaru @endif
                </h2>
                <p class="text-gray-500 text-sm mt-1">
                    Menampilkan item thrift @if($kategoriAktif != 'all') kategori {{ $kategoriAktif }} @else pilihan terbaik bulan ini @endif.
                </p>
            </div>
            
            <div class="flex flex-wrap gap-2">
    <a href="{{ url('/?kategori=all') }}" class="btn-thrift-nav {{ $kategoriAktif == 'all' ? 'active' : '' }}">Semua</a>
    <a href="{{ url('/?kategori=Baju') }}" class="btn-thrift-nav {{ $kategoriAktif == 'Baju' ? 'active' : '' }}">Baju</a>
    <a href="{{ url('/?kategori=Celana') }}" class="btn-thrift-nav {{ $kategoriAktif == 'Celana' ? 'active' : '' }}">Celana</a>
    <a href="{{ url('/?kategori=Wanita') }}" class="btn-thrift-nav {{ $kategoriAktif == 'Wanita' ? 'active' : '' }}">Wanita</a> </div>
            </div>
        </div>
        
        <div style="display: flex; flex-wrap: wrap; gap: 1.5rem; justify-content: flex-start;">
            
            @forelse($produk as $item)
                <div class="thrift-product-card">
                    <div style="position: relative; width: 100%; height: 260px; background-image: url('{{ asset('storage/' . $item->gambar) }}'); background-size: cover; background-position: center;">
                        <span style="position: absolute; top: 12px; left: 12px; background-color: #506049; color: white; font-size: 11px; font-weight: 600; padding: 4px 8px; border-radius: 0.5rem;">STOK: {{ $item->stok }}</span>
                    </div>
                    <div class="p-4 flex flex-col justify-between flex-1">
                        <div>
                            <span class="card-sub">UKURAN {{ strtoupper($item->ukuran) }}</span>
                            <h4 class="card-title">{{ $item->nama_produk }}</h4>
                            <p class="card-price">Rp {{ number_format($item->harga, 0, ',', '.') }}</p>
                        </div>
                        <a href="{{ url('/detail/' . $item->id_produk) }}" class="btn-thrift-action">Lihat Detail</a>
                    </div>
                </div>
            @empty
                <div class="w-full text-center py-12">
                    <p class="text-gray-400 italic">Belum ada produk thrifting tersedia untuk kategori ini.</p>
                </div>
            @endforelse

        </div>
    </div>
</section>

<style>
    .btn-thrift-nav {
        background-color: #ffffff;
        color: #1b1c1c;
        border: 1px solid #e3e3e0;
        padding: 6px 18px;
        font-size: 0.85rem;
        font-weight: 500;
        border-radius: 1.5rem;
        text-decoration: none;
        display: inline-block;
        transition: all 0.2s ease;
    }
    .btn-thrift-nav.active, .btn-thrift-nav:hover {
        background-color: #506049 !important;
        color: #ffffff !important;
        border-color: #506049;
    }
    .thrift-product-card {
        background: #ffffff; 
        border: 1px solid #e3e3e0; 
        border-radius: 1rem; 
        overflow: hidden; 
        display: flex; 
        flex-direction: column; 
        width: 260px; 
        min-width: 260px; 
        max-width: 260px;
        transition: transform 0.2s ease;
    }
    .thrift-product-card:hover { transform: translateY(-4px); }
    .card-sub { font-size: 11px; font-weight: 700; color: #757870; letter-spacing: 0.05em; text-transform: uppercase; }
    .card-title { font-family: ui-serif, Georgia, serif; font-size: 1.1rem; color: #1b1c1c; margin-top: 4px; font-weight: 500; line-height: 1.4; }
    .card-price { color: #1b1c1c; font-size: 1rem; margin-top: 4px; font-weight: 600; }
    .btn-thrift-action { display: block; text-align: center; background-color: transparent; color: #1b1c1c; border: 1.5px solid #1b1c1c; border-radius: 1.5rem; padding: 8px; font-size: 0.85rem; font-weight: 600; text-decoration: none; margin-top: 1rem; transition: all 0.2s; }
    .btn-thrift-action:hover { background-color: #1b1c1c; color: #ffffff; }
</style>