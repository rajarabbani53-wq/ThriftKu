<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - ThriftKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Plus+Jakarta+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { background-color: #F4F1EA; font-family: 'Plus Jakarta Sans', sans-serif; color: #2B2B2B; }
        .navbar-thrift { background-color: #3D4A3E; }
        .navbar-brand { font-family: 'Playfair Display', serif; font-size: 1.8rem; color: #F4F1EA !important; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); background-color: #FFFFFF; }
        .btn-thrift { background-color: #3D4A3E; color: #FFFFFF; border: none; border-radius: 6px; text-decoration: none; }
        .btn-thrift:hover { background-color: #2B352C; color: #FFFFFF; }
        .product-badge { background-color: #A3B19B; color: #2B352C; font-weight: 600; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-thrift shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand" href="/dashboard">ThriftKu Admin</a>
        <div class="d-flex">
            <a href="/login" class="btn btn-outline-light btn-sm">Keluar</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold" style="color: #3D4A3E;">Katalog Barang Thrift</h2>
            <p class="text-muted m-0">Kelola produk pakaian preloved yang tersedia di toko.</p>
        </div>
        <a href="/produk/tambah" class="btn btn-thrift px-4 py-2">+ Tambah Produk Baru</a>
    </div>

    <div class="row row-cols-1 row-cols-md-3 g-4">
        <div class="col">
            <div class="card h-100 card-custom overflow-hidden">
                <div style="background-color: #E2E2E2; height: 250px; display: flex; align-items: center; justify-content: center; color: #777;">
                    [ Foto Crewneck Vintage ]
                </div>
                <div class="card-body">
                    <span class="badge product-badge mb-2">Crewneck</span>
                    <h5 class="card-title fw-bold">Crewneck Oversize Vintage Nike</h5>
                    <p class="card-text text-muted text-truncate">Kondisi 9/10, karet aman, warna masih pekat banget seperti baru.</p>
                    <h5 class="fw-bold text-success">Rp 145.000</h5>
                </div>
                <div class="card-footer bg-transparent border-top-0 d-flex gap-2 pb-3">
                    <button class="btn btn-sm btn-outline-secondary w-50">Edit</button>
                    <button class="btn btn-sm btn-outline-danger w-50">Hapus</button>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 card-custom overflow-hidden">
                <div style="background-color: #E2E2E2; height: 250px; display: flex; align-items: center; justify-content: center; color: #777;">
                    [ Foto Celana Levi's ]
                </div>
                <div class="card-body">
                    <span class="badge product-badge mb-2">Celana Jeans</span>
                    <h5 class="card-title fw-bold">Levi's 501 Original Denim</h5>
                    <p class="card-text text-muted text-truncate">Size 32, lingkar pinggang pas, kikis tipis di bagian bawah wajar pemakaian.</p>
                    <h5 class="fw-bold text-success">Rp 210.000</h5>
                </div>
                <div class="card-footer bg-transparent border-top-0 d-flex gap-2 pb-3">
                    <button class="btn btn-sm btn-outline-secondary w-50">Edit</button>
                    <button class="btn btn-sm btn-outline-danger w-50">Hapus</button>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>