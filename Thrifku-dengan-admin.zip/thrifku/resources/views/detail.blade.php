<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - ThriftKu</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        body { background-color: #f9f9f7; color: #1b1c1c; }
        .font-serif-thrift { font-family: ui-serif, Georgia, Cambria, serif; }
        .btn-olive { background-color: #506049; color: #ffffff; }
        .btn-olive:hover { background-color: #3d4a37; }
    </style>
</head>
<body class="flex flex-col min-h-screen">

    <nav class="border-b border-[#e3e3e0] bg-white px-6 py-4 flex justify-between items-center">
        <a href="/" class="text-2xl font-bold font-serif-thrift tracking-tight">ThriftKu</a>
        <div class="flex items-center gap-6 text-sm font-medium text-gray-600">
            <a href="/" class="hover:text-black">Beranda</a>
            <a href="/riwayat" class="hover:text-black">Riwayat Pesanan</a>
            <a href="#" class="relative">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
            </a>
        </div>
    </nav>

    <main class="flex-1 max-w-5xl w-full mx-auto p-4 md:p-8 grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-start my-4">
        
        <div class="relative w-full aspect-square smd:aspect-[4/5] bg-cover bg-center rounded-xl border border-[#e3e3e0] overflow-hidden bg-white" 
             style="background-image: url('{{ asset('storage/' . $item->gambar) }}');">
            <div class="absolute top-4 left-4 flex flex-col gap-1.5">
                <span class="bg-[#506049]/90 text-white text-[10px] font-bold px-2.5 py-1 rounded tracking-wide uppercase">Eco-Verified</span>
                <span class="bg-amber-800/90 text-white text-[10px] font-bold px-2.5 py-1 rounded tracking-wide uppercase">Vintage Rare</span>
            </div>
        </div>

        <div class="space-y-6">
            <div>
                <span class="text-xs font-bold text-gray-400 tracking-wider uppercase block">{{ $item->kategori }}</span>
                <h1 class="text-3xl font-bold font-serif-thrift text-[#1b1c1c] mt-1 leading-tight">{{ $item->nama_produk }}</h1>
                <div class="flex items-center gap-3 mt-3">
                    <span class="text-xl font-bold text-[#1b1c1c]">Rp {{ number_format($item->harga, 0, ',', '.') }}</span>
                    <span class="text-xs bg-emerald-50 text-emerald-700 font-medium px-2 py-0.5 rounded border border-emerald-200">Tersedia</span>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="bg-white p-3.5 border border-[#e3e3e0] rounded-xl">
                    <span class="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Ukuran</span>
                    <span class="text-sm font-semibold text-gray-800 block mt-1">{{ $item->ukuran }} (Oversized)</span>
                </div>
                <div class="bg-white p-3.5 border border-[#e3e3e0] rounded-xl">
                    <span class="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Kondisi</span>
                    <span class="text-sm font-semibold text-gray-800 block mt-1">9/10 Grade A</span>
                </div>
            </div>

            <div class="space-y-2">
                <h3 class="text-xs font-bold text-gray-500 uppercase tracking-wider">Deskripsi Produk</h3>
                <p class="text-xs md:text-sm text-gray-600 leading-relaxed">
                    Kondisi 9/10, warna pekat, minus noda samar di lengan. Item thrift ini memiliki potongan premium yang klasik, sangat cocok untuk gaya streetwear maupun casual vintage Anda. Bahan tebal berkualitas tinggi yang tahan lama dan mendukung gerakan berkelanjutan.
                </p>
            </div>

            <div class="space-y-2 pt-2 text-xs text-gray-600">
                <div class="flex items-center gap-2">
                    <svg class="w-4 h-4 text-[#506049]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path></svg>
                    <span>Sudah dicuci & disterilkan (Laundry Clean)</span>
                </div>
                <div class="flex items-center gap-2">
                    <svg class="w-4 h-4 text-[#506049]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path></svg>
                    <span>Pengecekan kualitas 3 tahap</span>
                </div>
            </div>

            <div class="pt-4">
                <button class="w-full btn-olive text-sm font-semibold py-3.5 rounded-full transition flex items-center justify-center gap-2.5 shadow-sm cursor-pointer">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                    Masukkan Keranjang
                </button>
                <span class="block text-center text-[10px] text-gray-400 mt-2">Setiap pembelian mendukung sirkularitas fashion di Indonesia.</span>
            </div>
        </div>
    </main>

</body>
</html>