<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ThriftKu - Sustainable Minimalism Apparel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { background-color: #fbf9f8; font-family: 'Inter', sans-serif; color: #1b1c1c; }
        h1, h2, h3, .brand-font { font-family: 'Playfair Display', serif; }
        
        /* Navbar Glassmorphism Effect */
        .navbar-thrift { background: rgba(251, 249, 248, 0.8); backdrop-filter: blur(8px); border-bottom: 1px solid #e4e2e1; sticky-top: true; }
        .navbar-brand { font-size: 1.8rem; font-weight: 700; color: #506049 !important; }
        .nav-link-custom { color: #1b1c1c; font-weight: 400; text-decoration: none; font-size: 0.95rem; }
        
        /* Hero Section */
        .hero-banner { 
            background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)), url('https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=1200') no-repeat center center;
            background-size: cover;
            min-height: 500px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            text-align: center;
        }
        .btn-sage-pill { background-color: #506049; color: #ffffff; border-radius: 9999px; font-weight: 600; padding: 12px 32px; border: none; transition: 0.3s; }
        .btn-sage-pill:hover { background-color: #3c4b35; color: #ffffff; }
        .btn-outline-pill { background-color: transparent; color: #ffffff; border: 1.5px solid #ffffff; border-radius: 9999px; font-weight: 600; padding: 12px 32px; transition: 0.3s; text-decoration: none; }
        .btn-outline-pill:hover { background-color: #ffffff; color: #1b1c1c; }

        /* Filter Chips */
        .filter-chip { border: 1px solid #c4c8be; border-radius: 9999px; padding: 6px 20px; color: #1b1c1c; text-decoration: none; font-size: 0.85rem; background: transparent; transition: 0.3s; }
        .filter-chip.active { background-color: #506049; color: white; border-color: #506049; }

        /* Product Cards 1:1 Gallery Layout */
        .card-product { border: 1px solid #e4e2e1; border-radius: 1rem; background-color: #ffffff; overflow: hidden; transition: transform 0.3s ease; }
        .card-product:hover { transform: translateY(-5px); }
        .img-wrapper { aspect-ratio: 1 / 1; background-color: #f6f3f2; overflow: hidden; position: relative; }
        .img-wrapper img { width: 100%; height: 100%; object-fit: cover; }
        
        /* Badges */
        .badge-custom { position: absolute; top: 12px; left: 12px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; padding: 4px 10px; border-radius: 4px; letter-spacing: 0.05em; }
        .bg-condition { background-color: #757870; color: white; }
        .bg-rare { background-color: #ae611a; color: white; }
        .bg-eco { background-color: #506049; color: white; }
        
        .label-caps { font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em; color: #757870; text-transform: uppercase; }
        .product-title { font-size: 1.25rem; font-weight: 600; color: #1b1c1c; text-decoration: none; display: block; margin-top: 4px; }
        .product-price { font-size: 1.1rem; font-weight: 700; color: #1b1c1c; margin-top: 8px; }
        
        .btn-detail { border: 1px solid #1b1c1c; border-radius: 4px; background: transparent; width: 100%; padding: 8px; font-size: 0.85rem; font-weight: 600; transition: 0.3s; }
        .btn-detail:hover { background-color: #1b1c1c; color: white; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-thrift sticky-top py-3">
    <div class="container">
        <a class="navbar-brand" href="/">ThriftKu</a>
        <div class="d-flex align-items-center gap-4">
            <a href="#" class="nav-link-custom">Riwayat Pesanan</a>
            <a href="/keranjang" class="nav-link-custom position-relative">
                🛒 <span class="position-absolute top-0start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.65rem;">2</span>
            </a>
            <a href="/login" class="nav-link-custom">Logout</a>
        </div>
    </div>
</nav>

<header class="hero-banner mb-5">
    <div class="container">
        <h1 class="display-3 fw-bold mb-3" style="max-width: 800px; margin: 0 auto;">Temukan Pakaian Preloved Berkualitas</h1>
        <p class="lead mb-4" style="max-width: 600px; margin: 0 auto; font-weight: 400; opacity: 0.9;">Kurasi fashion berkelanjutan dengan sentuhan vintage yang abadi. Pilihan terbaik untuk gaya hidup minimalis Anda.</p>
        <div class="d-flex justify-content-center gap-3">
            <button class="btn-sage-pill">Mulai Jelajah</button>
            <a href="#" class="btn-outline-pill">Tentang Kami</a>
        </div>
    </div>
</header>

<main class="container mb-5">
    <div class="d-flex justify-content-between align-items-end mb-4">
        <div>
            <h2 class="fw-bold mb-1">Koleksi Terbaru</h2>
            <p class="text-muted small m-0">Menampilkan item terpilih untuk bulan ini.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="#" class="filter-chip active">Semua</a>
            <a href="#" class="filter-chip">Baju</a>
            <a href="#" class="filter-chip">Celana</a>
            <a href="#" class="filter-chip">Aksesoris</a>
        </div>
    </div>

    <div class="row row-cols-1 row-cols-md-4 g-4">
        <div class="col">
            <div class="card-product p-3">
                <div class="img-wrapper rounded mb-3">
                    <span class="badge-custom bg-condition">KONDISI 9/10</span>
                    <img src="https://images.unsplash.com/photo-1598033129183-c4f50c736f10?q=80&w=400" alt="Kemeja">
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="label-caps">UKURAN L</span>
                </div>
                <a href="#" class="product-title">Kemeja Flanel Vintage</a>
                <div class="product-price">Rp 85.000</div>
                <button class="btn-detail mt-3">Lihat Detail</button>
            </div>
        </div>

        <div class="col">
            <div class="card-product p-3">
                <div class="img-wrapper rounded mb-3">
                    <span class="badge-custom bg-rare">RARE FIND</span>
                    <img src="https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=400" alt="Celana">
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="label-caps">UKURAN 32</span>
                </div>
                <a href="#" class="product-title">Celana Chino Klasik</a>
                <div class="product-price">Rp 120.000</div>
                <button class="btn-detail mt-3">Lihat Detail</button>
            </div>
        </div>

        <div class="col">
            <div class="card-product p-3">
                <div class="img-wrapper rounded mb-3">
                    <span class="badge-custom bg-eco">ECO-VERIFIED</span>
                    <img src="https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?q=80&w=400" alt="Sweater">
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="label-caps">UKURAN XL</span>
                </div>
                <a href="#" class="product-title">Oversized Knit Sweater</a>
                <div class="product-price">Rp 150.000</div>
                <button class="btn-detail mt-3">Lihat Detail</button>
            </div>
        </div>

        <div class="col">
            <div class="card-product p-3">
                <div class="img-wrapper rounded mb-3">
                    <span class="badge-custom bg-condition">90S DENIM</span>
                    <img src="https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=400" alt="Jaket">
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="label-caps">UKURAN M</span>
                </div>
                <a href="#" class="product-title">Jaket Denim Washed</a>
                <div class="product-price">Rp 195.000</div>
                <button class="btn-detail mt-3">Lihat Detail</button>
            </div>
        </div>
    </div>
</main>

<hr class="container my-5" style="border-color: #e4e2e1;">

<section class="container mb-5 py-4">
    <div class="row align-items-center bg-white p-5 rounded-lg border shadow-sm">
        <div class="col-md-7">
            <h2 class="fw-bold fs-1 mb-3">Bergabung dengan Gerakan Fashion Lambat</h2>
            <p class="text-muted mb-0" style="max-width: 550px;">Setiap pakaian memiliki cerita. Dengan memilih preloved, Anda memperpanjang siklus hidup sebuah karya fashion dan mengurangi limbah tekstil dunia.</p>
            <div class="d-flex gap-5 mt-4">
                <div><h3 class="fw-bold m-0 text-success">500+</h3><small class="text-muted">Pakaian Terselamatkan</small></div>
                <div><h3 class="fw-bold m-0 text-success">100%</h3><small class="text-muted">Kurasi Kualitas</small></div>
            </div>
        </div>
        <div class="col-md-5 mt-4 mt-md-0">
            <div class="p-4 rounded" style="background-color: #f6f3f2;">
                <h5 class="fw-bold mb-2">Dapatkan Update Koleksi</h5>
                <p class="small text-muted mb-3">Jadilah yang pertama tahu saat kami meluncurkan batch vintage terbaru.</p>
                <div class="input-group">
                    <input type="email" class="form-control" placeholder="Alamat email Anda" style="border-radius: 8px 0 0 8px;">
                    <button class="btn btn-dark px-3" style="border-radius: 0 8px 8px 0; background-color: #506049; border:none;">Berlangganan</button>
                </div>
            </div>
        </div>
    </div>
</section>

</body>
</html>