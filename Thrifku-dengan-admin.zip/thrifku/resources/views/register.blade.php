<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - ThriftKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { background-color: #fbf9f8; font-family: 'Inter', sans-serif; color: #1b1c1c; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 40px 0; }
        .brand-title { font-family: 'Playfair Display', serif; font-size: 3rem; text-align: center; color: #506049; margin-bottom: 30px; }
        .register-card { background: #ffffff; border: 1px solid #e4e2e1; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); width: 100%; max-width: 480px; overflow: hidden; }
        .tab-nav { display: flex; border-bottom: 1px solid #e4e2e1; }
        .tab-item { flex: 1; text-align: center; padding: 15px; text-decoration: none; color: #757870; font-weight: 600; font-size: 0.9rem; letter-spacing: 0.05em; }
        .tab-item.active { color: #1b1c1c; border-bottom: 2px solid #506049; }
        .form-label { font-size: 0.75rem; font-weight: 700; color: #444841; letter-spacing: 0.03em; }
        .form-control { border: 1px solid #c4c8be; border-radius: 6px; padding: 10px 14px; background-color: #fbf9f8; }
        .form-control:focus { background-color: #ffffff; border-color: #506049; box-shadow: none; }
        .btn-register { background-color: #506049; color: white; border-radius: 9999px; font-weight: 600; padding: 12px; width: 100%; border: none; margin-top: 20px; text-transform: uppercase; font-size: 0.9rem; letter-spacing: 0.05em; }
        .btn-register:hover { background-color: #3c4b35; }
    </style>
</head>
<body>

<div>
    <h1 class="brand-title">ThriftKu</h1>
    
    <div class="register-card">
        <div class="tab-nav">
            <a href="/login" class="tab-item">MASUK</a>
            <a href="/register" class="tab-item active">DAFTAR</a>
        </div>
        
        <div class="p-4">
            <div class="text-center mb-4">
                <h3 class="fw-bold m-0" style="font-family: 'Playfair Display', serif;">Buat Akun</h3>
                <p class="text-muted small">Bergabunglah dalam gerakan fashion berkelanjutan.</p>
            </div>
            
            <form action="#" method="POST">
                <div class="mb-3">
                    <label class="form-label">EMAIL</label>
                    <input type="email" class="form-control" placeholder="nama@email.com" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">TELEPON / WHATSAPP</label>
                    <input type="text" class="form-control" placeholder="0812xxxx" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">ALAMAT LENGKAP</label>
                    <input type="text" class="form-control" placeholder="Jl. Raya No. 123..." required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">KATA SANDI</label>
                    <input type="password" class="form-control" placeholder="••••••••" required>
                </div>
                
                <div class="form-check mt-3">
                    <input class="form-check-input" type="checkbox" id="agree" required>
                    <label class="form-check-label small text-muted" for="agree">
                        Saya setuju dengan Syarat & Ketentuan yang berlaku.
                    </label>
                </div>
                
                <button type="submit" class="btn-register">Daftar Akun</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>