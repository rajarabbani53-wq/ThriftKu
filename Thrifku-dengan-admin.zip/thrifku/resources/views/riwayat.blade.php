<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan - ThriftKu</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        body { background-color: #f9f9f7; color: #1b1c1c; }
        .font-serif-thrift { font-family: ui-serif, Georgia, Cambria, serif; }
    </style>
</head>
<body class="flex flex-col min-h-screen">

    <nav class="border-b border-[#e3e3e0] bg-white px-6 py-4 flex justify-between items-center">
        <a href="/" class="text-2xl font-bold font-serif-thrift tracking-tight">ThriftKu</a>
        <div class="flex items-center gap-6 text-sm font-medium text-gray-600">
            <a href="/" class="hover:text-black">Koleksi</a>
            <a href="#" class="text-black underline decoration-[#506049] underline-offset-4">Riwayat Pesanan</a>
            <a href="/login" class="hover:text-black">Logout</a>
        </div>
    </nav>

    <main class="flex-1 max-w-4xl w-full mx-auto p-4 md:p-8 my-4">
        <div class="mb-8">
            <h1 class="text-3xl font-bold font-serif-thrift text-gray-900">Riwayat Pesanan</h1>
            <p class="text-xs text-gray-500 mt-1">Pantau status pengiriman dan riwayat belanja kurasi vintage Anda.</p>
        </div>

        <div class="space-y-5">
            
            <div class="bg-white border border-[#e3e3e0] rounded-xl p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
                <div class="space-y-3">
                    <div class="flex flex-wrap items-center gap-3 text-xs">
                        <span class="font-bold text-gray-700">ORDER ID <span class="text-gray-950">#TK-001</span></span>
                        <span class="text-gray-400">•</span>
                        <span class="text-gray-500">24 Oktober 2023</span>
                        <span class="text-gray-400">•</span>
                        <span class="text-gray-500 flex items-center gap-1">🚚 JNE Reguler</span>
                    </div>
                    <div class="flex gap-2">
                        <div class="w-12 h-12 rounded-lg bg-cover bg-center border border-gray-100" style="background-image: url('https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=100');"></div>
                        <div class="w-12 h-12 rounded-lg bg-cover bg-center border border-gray-100" style="background-image: url('https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?q=80&w=100');"></div>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row md:flex-col items-start sm:items-center md:items-end justify-between w-full md:w-auto gap-3 border-t md:border-0 pt-3 md:pt-0 border-gray-100">
                    <div class="text-left md:text-right">
                        <span class="text-xs text-gray-400 block">Total Pembayaran</span>
                        <span class="font-bold text-base text-gray-900">Rp 450.000</span>
                    </div>
                    <span class="bg-emerald-50 text-emerald-700 text-[10px] font-bold tracking-wider px-2.5 py-1 rounded border border-emerald-200 uppercase">✓ Terkonfirmasi</span>
                    <a href="https://wa.me/612345678" target="_blank" class="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-medium px-4 py-2 rounded-lg transition flex items-center gap-1.5 w-full sm:w-auto justify-center">
                        💬 Hubungi Admin via WhatsApp
                    </a>
                </div>
            </div>

            <div class="bg-white border border-[#e3e3e0] rounded-xl p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
                <div class="space-y-3">
                    <div class="flex flex-wrap items-center gap-3 text-xs">
                        <span class="font-bold text-gray-700">ORDER ID <span class="text-gray-950">#TK-002</span></span>
                        <span class="text-gray-400">•</span>
                        <span class="text-gray-500">25 Oktober 2023</span>
                        <span class="text-gray-400">•</span>
                        <span class="text-gray-500 flex items-center gap-1">🏪 Ambil di Toko</span>
                    </div>
                    <div class="flex gap-2">
                        <div class="w-12 h-12 rounded-lg bg-cover bg-center border border-gray-100" style="background-image: url('https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=100');"></div>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row md:flex-col items-start sm:items-center md:items-end justify-between w-full md:w-auto gap-3 border-t md:border-0 pt-3 md:pt-0 border-gray-100">
                    <div class="text-left md:text-right">
                        <span class="text-xs text-gray-400 block">Total Pembayaran</span>
                        <span class="font-bold text-base text-gray-900">Rp 1.200.000</span>
                    </div>
                    <span class="bg-amber-50 text-amber-700 text-[10px] font-bold tracking-wider px-2.5 py-1 rounded border border-amber-200 uppercase">🕒 Pending</span>
                    <a href="https://wa.me/612345678" target="_blank" class="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-medium px-4 py-2 rounded-lg transition flex items-center gap-1.5 w-full sm:w-auto justify-center">
                        💬 Hubungi Admin via WhatsApp
                    </a>
                </div>
            </div>

            <div class="bg-white border border-[#e3e3e0] rounded-xl p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm opacity-75">
                <div class="space-y-3">
                    <div class="flex flex-wrap items-center gap-3 text-xs">
                        <span class="font-bold text-gray-700">ORDER ID <span class="text-gray-950">#TK-003</span></span>
                        <span class="text-gray-400">•</span>
                        <span class="text-gray-500">20 Oktober 2023</span>
                        <span class="text-gray-400">•</span>
                        <span class="text-gray-500 flex items-center gap-1">📦 SiCepat</span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row md:flex-col items-start sm:items-center md:items-end justify-between w-full md:w-auto gap-3 border-t md:border-0 pt-3 md:pt-0 border-gray-100">
                    <div class="text-left md:text-right">
                        <span class="text-xs text-gray-400 block">Total Pembayaran</span>
                        <span class="font-bold text-sm text-gray-500 line-through">Rp 275.000</span>
                    </div>
                    <div class="text-left md:text-right">
                        <span class="bg-gray-100 text-gray-600 text-[10px] font-bold tracking-wider px-2.5 py-1 rounded border border-gray-200 uppercase inline-block">✕ Dibatalkan</span>
                        <span class="block text-[10px] text-gray-400 italic mt-1">Alasan Pembatalan: Stok habis</span>
                    </div>
                </div>
            </div>

        </div>

        <div class="text-center mt-8">
            <button class="border border-gray-300 text-gray-600 text-xs font-semibold px-6 py-2.5 rounded-full hover:bg-gray-50 transition cursor-pointer">
                Tampilkan Pesanan Lainnya
            </button>
        </div>
    </main>

</body>
<!-- ================= FOOTER UTAMA THRIFTKU ================= -->
    <footer class="bg-[#f5f3f0] border-t border-[#e3e3e0] mt-16 py-12 px-6 md:px-16">
        <div class="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-start gap-10">
            
            <!-- Sisi Kiri: Deskripsi & Hak Cipta -->
            <div class="space-y-3 max-w-sm">
                <span class="text-2xl font-bold font-serif-thrift tracking-tight text-gray-900">ThriftKu</span>
                <p class="text-xs text-gray-500 leading-relaxed">
                    © 2024 ThriftKu. Sustainable Minimalism for Indonesian Fashion. Kurasi barang vintage terbaik untuk gaya hidup yang lebih hijau.
                </p>
            </div>

            <!-- Sisi Tengah: Tautan Cepat Navigasi -->
            <div class="space-y-3">
                <h4 class="text-xs font-bold text-gray-900 tracking-wider uppercase">Tautan Cepat</h4>
                <ul class="space-y-2 text-xs text-gray-600">
                    <li><a href="#" class="hover:text-[#506049] transition">Tentang Kami</a></li>
                    <li><a href="#" class="hover:text-[#506049] transition">Panduan Ukuran</a></li>
                    <li><a href="#" class="hover:text-[#506049] transition">Kebijakan Privasi</a></li>
                    <li><a href="#" class="hover:text-[#506049] transition">Kontak</a></li>
                </ul>
            </div>

            <!-- Sisi Kanan: Sosial Media & Lokasi -->
            <div class="space-y-4">
                <div>
                    <h4 class="text-xs font-bold text-gray-900 tracking-wider uppercase mb-2">Ikuti Kami</h4>
                    <div class="flex items-center gap-2">
                        <!-- Tombol Lingkaran Instagram/Sosmed 1 -->
                        <a href="#" class="w-8 h-8 rounded-full bg-white border border-[#e3e3e0] flex items-center justify-center text-gray-600 hover:bg-[#506049] hover:text-white transition shadow-sm">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                            </svg>
                        </a>
                        <!-- Tombol Lingkaran Website/Sosmed 2 -->
                        <a href="#" class="w-8 h-8 rounded-full bg-white border border-[#e3e3e0] flex items-center justify-center text-gray-600 hover:bg-[#506049] hover:text-white transition shadow-sm">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="2" y1="12" x2="22" y2="12"></line>
                                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                            </svg>
                        </a>
                    </div>
                </div>
                <div>
                    <span class="text-[10px] font-bold text-gray-400 uppercase block tracking-wider">Lokasi Kami</span>
                    <span class="text-xs text-gray-600 font-medium block mt-0.5">Jakarta Selatan, Indonesia</span>
                </div>
            </div>

        </div>
    </footer>   
</html>