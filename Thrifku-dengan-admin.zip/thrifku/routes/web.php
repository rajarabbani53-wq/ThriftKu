<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

// 1. HALAMAN UTAMA (KATALOG KOLEKSI)
Route::get('/', function (Request $request) {
    // Ambil input kategori dari URL, default-nya 'all' jika tidak ada
    $kategoriAktif = $request->query('kategori', 'all');

    // Query dasar: hanya ambil produk yang stoknya > 0
    $query = DB::table('produk')->where('stok', '>', 0);

    // Jika filternya bukan 'all', saring berdasarkan kategori (Baju / Celana / Wanita)
    if ($kategoriAktif !== 'all') {
        $query->where('kategori', $kategoriAktif);
    }

    $produk = $query->get();

    // Kirim data $produk dan $kategoriAktif ke halaman view
    return view('welcome', compact('produk', 'kategoriAktif')); 
});

// 2. HALAMAN DETAIL PRODUK (Menggunakan ID dinamis dari database)
Route::get('/detail/{id}', function ($id) {
    $item = DB::table('produk')->where('id_produk', $id)->first();
    
    // Jika produk tidak ditemukan, kembalikan ke halaman utama
    if (!$item) {
        return redirect('/');
    }
    
    return view('detail', compact('item'));
});

// Menampilkan halaman login (Sudah ada)
Route::get('/login', function () {
    return view('login');
});

// Menerima kiriman data form login (Tambahkan ini)
Route::post('/login', function (Request $request) {
    // Sementara kita langsung arahkan kembali ke beranda setelah submit
    return redirect('/');
});

// 4. HALAMAN RIWAYAT PESANAN
Route::get('/riwayat', function () { 
    return view('riwayat'); 
});

// 5. HALAMAN KERANJANG BELANJA
Route::get('/cart', function () { 
    return view('cart'); 
});

// ================= ADMIN =================
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ProdukController;
use App\Http\Controllers\Admin\PesananController;
use App\Http\Controllers\Admin\PelangganController;

Route::prefix('admin')->name('admin.')->group(function () {
    // Login admin (tidak perlu middleware)
    Route::get('/login', [AdminAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('login.submit');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

    // Halaman terproteksi (wajib login admin)
    Route::middleware('admin.auth')->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        Route::resource('produk', ProdukController::class)->except(['show'])->names('produk');

        Route::get('/pesanan', [PesananController::class, 'index'])->name('pesanan.index');
        Route::post('/pesanan/{pesanan}/konfirmasi', [PesananController::class, 'konfirmasi'])->name('pesanan.konfirmasi');
        Route::post('/pesanan/{pesanan}/batalkan', [PesananController::class, 'batalkan'])->name('pesanan.batalkan');

        Route::get('/pelanggan', [PelangganController::class, 'index'])->name('pelanggan.index');
        Route::delete('/pelanggan/{pelanggan}', [PelangganController::class, 'destroy'])->name('pelanggan.destroy');
    });
});