<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang - ThriftKu</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        body { background-color: #ffffff; color: #1b1c1c; }
        .font-serif-thrift { font-family: ui-serif, Georgia, Cambria, serif; }
        .btn-olive { background-color: #506049; color: #ffffff; }
        .btn-olive:hover { background-color: #3d4a37; }
    </style>
</head>
<body class="min-h-screen flex flex-col justify-between">

    <main class="flex-1 grid grid-cols-1 md:grid-cols-2 min-h-[calc(100vh-60px)]">
        
        <div class="hidden md:flex relative flex-col justify-between p-12 bg-cover bg-center min-h-full text-white" 
             style="background-image: linear-gradient(to bottom, rgba(0,0,0,0.2), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?q=80&w=800');">
            
            <div class="text-3xl font-bold font-serif-thrift tracking-tight">
                ThriftKu
            </div>

            <div class="space-y-4 max-w-md">
                <h1 class="text-4xl font-bold font-serif-thrift leading-tight">
                    Mulai Perjalanan Sustainable Fashion-mu.
                </h1>
                <p class="text-sm text-gray-200 leading-relaxed">
                    Temukan koleksi kurasi pakaian vintage terbaik dengan sentuhan minimalis modern yang ramah lingkungan.
                </p>
                <div class="flex items-center gap-3 pt-2">
                    <div class="flex -space-x-2">
                        <img class="w-7 h-7 rounded-full border border-white" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=100" alt="user">
                        <img class="w-7 h-7 rounded-full border border-white" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=100" alt="user">
                        <img class="w-7 h-7 rounded-full border border-white" src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100" alt="user">
                    </div>
                    <span class="text-xs text-gray-300 font-medium">BERGABUNG DENGAN 5K+ PENGGUNA</span>
                </div>
            </div>
        </div>

        <div class="flex items-center justify-center p-8 md:p-16 bg-white">
            <div class="w-full max-w-sm space-y-8">
                
                <div class="space-y-2">
                    <div class="text-2xl font-bold font-serif-thrift text-gray-900 md:hidden mb-4">ThriftKu</div>
                    <h2 class="text-3xl font-bold font-serif-thrift text-gray-900 tracking-tight">Selamat Datang</h2>
                    <p class="text-xs text-gray-500">Silakan masuk ke akun Anda untuk melanjutkan belanja.</p>
                </div>

                <form action="<?php echo e(url('/')); ?>" method="GET" class="space-y-5">
                    <div class="space-y-1.5">
                        <label for="email" class="text-[10px] font-bold text-gray-500 uppercase tracking-wider block">Email</label>
                        <input type="email" id="email" name="email" required placeholder="nama@email.com"
                               class="w-full text-sm px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-[#506049] focus:bg-white transition">
                    </div>

                    <div class="space-y-1.5">
                        <div class="flex justify-between items-center">
                            <label for="password" class="text-[10px] font-bold text-gray-500 uppercase tracking-wider block">Kata Sandi</label>
                            <a href="#" class="text-[11px] text-gray-400 hover:text-[#506049] transition">Lupa kata sandi?</a>
                        </div>
                        <input type="password" id="password" name="password" required placeholder="••••••••"
                               class="w-full text-sm px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-[#506049] focus:bg-white transition">
                    </div>

                    <div class="pt-2">
                        <button type="submit" class="w-full btn-olive text-xs font-semibold py-3.5 rounded-full transition flex items-center justify-center gap-2 cursor-pointer shadow-sm">
                            Masuk
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                        </button>
                    </div>
                </form>

                <div class="text-center pt-2">
                    <p class="text-xs text-gray-500">
                        Belum memiliki akun? 
                        <a href="/register" class="font-semibold text-gray-900 hover:text-[#506049] underline decoration-[#506049] underline-offset-4 transition">Daftar Sekarang</a>
                    </p>
                </div>

            </div>
        </div>
    </main>

    <footer class="py-4 border-t border-gray-100 text-center text-[10px] text-gray-400 uppercase tracking-wider">
        © 2024 ThriftKu • Sustainable Minimalism Indonesia
    </footer>

</body>
</html><?php /**PATH C:\File Tugas 2025\File Pak Arka Semes 4 Web Lanjut\Trifhku\TrifhKu\Thrifku\resources\views/login.blade.php ENDPATH**/ ?>