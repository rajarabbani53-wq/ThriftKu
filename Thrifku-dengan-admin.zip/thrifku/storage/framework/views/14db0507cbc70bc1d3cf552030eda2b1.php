<section class="py-12" style="background-color: #fbf9f8;">
    <div class="mx-auto max-w-6xl px-4 sm:px-6">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
                <h2 style="color: #1b1c1c; font-size: 2rem; font-family: ui-serif, Georgia, Cambria, serif;" class="font-semibold">
                    <?php if($kategoriAktif == 'Baju'): ?> Koleksi Baju 
                    <?php elseif($kategoriAktif == 'Celana'): ?> Koleksi Celana
                    <?php else: ?> Koleksi Terbaru <?php endif; ?>
                </h2>
                <p class="text-gray-500 text-sm mt-1">
                    Menampilkan item thrift <?php if($kategoriAktif != 'all'): ?> kategori <?php echo e($kategoriAktif); ?> <?php else: ?> pilihan terbaik bulan ini <?php endif; ?>.
                </p>
            </div>
            
            <div class="flex flex-wrap gap-2">
    <a href="<?php echo e(url('/?kategori=all')); ?>" class="btn-thrift-nav <?php echo e($kategoriAktif == 'all' ? 'active' : ''); ?>">Semua</a>
    <a href="<?php echo e(url('/?kategori=Baju')); ?>" class="btn-thrift-nav <?php echo e($kategoriAktif == 'Baju' ? 'active' : ''); ?>">Baju</a>
    <a href="<?php echo e(url('/?kategori=Celana')); ?>" class="btn-thrift-nav <?php echo e($kategoriAktif == 'Celana' ? 'active' : ''); ?>">Celana</a>
    <a href="<?php echo e(url('/?kategori=Wanita')); ?>" class="btn-thrift-nav <?php echo e($kategoriAktif == 'Wanita' ? 'active' : ''); ?>">Wanita</a> </div>
            </div>
        </div>
        
        <div style="display: flex; flex-wrap: wrap; gap: 1.5rem; justify-content: flex-start;">
            
            <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="thrift-product-card">
                    <div style="position: relative; width: 100%; height: 260px; background-image: url('<?php echo e(asset('storage/' . $item->gambar)); ?>'); background-size: cover; background-position: center;">
                        <span style="position: absolute; top: 12px; left: 12px; background-color: #506049; color: white; font-size: 11px; font-weight: 600; padding: 4px 8px; border-radius: 0.5rem;">STOK: <?php echo e($item->stok); ?></span>
                    </div>
                    <div class="p-4 flex flex-col justify-between flex-1">
                        <div>
                            <span class="card-sub">UKURAN <?php echo e(strtoupper($item->ukuran)); ?></span>
                            <h4 class="card-title"><?php echo e($item->nama_produk); ?></h4>
                            <p class="card-price">Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></p>
                        </div>
                        <a href="<?php echo e(url('/detail/' . $item->id_produk)); ?>" class="btn-thrift-action">Lihat Detail</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="w-full text-center py-12">
                    <p class="text-gray-400 italic">Belum ada produk thrifting tersedia untuk kategori ini.</p>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>

<style>
    .btn-thrift-nav {
        background-color: #ffffff;
        color: #1b1c1c;
        border: 1px solid #e3e3e0;
        padding: 6px 18px;
        font-size: 0.85rem;
        font-weight: 500;
        border-radius: 1.5rem;
        text-decoration: none;
        display: inline-block;
        transition: all 0.2s ease;
    }
    .btn-thrift-nav.active, .btn-thrift-nav:hover {
        background-color: #506049 !important;
        color: #ffffff !important;
        border-color: #506049;
    }
    .thrift-product-card {
        background: #ffffff; 
        border: 1px solid #e3e3e0; 
        border-radius: 1rem; 
        overflow: hidden; 
        display: flex; 
        flex-direction: column; 
        width: 260px; 
        min-width: 260px; 
        max-width: 260px;
        transition: transform 0.2s ease;
    }
    .thrift-product-card:hover { transform: translateY(-4px); }
    .card-sub { font-size: 11px; font-weight: 700; color: #757870; letter-spacing: 0.05em; text-transform: uppercase; }
    .card-title { font-family: ui-serif, Georgia, serif; font-size: 1.1rem; color: #1b1c1c; margin-top: 4px; font-weight: 500; line-height: 1.4; }
    .card-price { color: #1b1c1c; font-size: 1rem; margin-top: 4px; font-weight: 600; }
    .btn-thrift-action { display: block; text-align: center; background-color: transparent; color: #1b1c1c; border: 1.5px solid #1b1c1c; border-radius: 1.5rem; padding: 8px; font-size: 0.85rem; font-weight: 600; text-decoration: none; margin-top: 1rem; transition: all 0.2s; }
    .btn-thrift-action:hover { background-color: #1b1c1c; color: #ffffff; }
</style><?php /**PATH C:\File Tugas 2025\File Pak Arka Semes 4 Web Lanjut\Trifhku\TrifhKu\Thrifku\resources\views/components/koleksi.blade.php ENDPATH**/ ?>