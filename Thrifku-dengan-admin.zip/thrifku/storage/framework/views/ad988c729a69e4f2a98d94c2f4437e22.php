<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ThriftKu - Sustainable Minimalism</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        body { background-color: #f9f9f7; color: #1b1c1c; }
        .font-serif-thrift { font-family: ui-serif, Georgia, Cambria, "Times New Roman", Times, serif; }
        .btn-olive { background-color: #506049; color: #ffffff; }
        .btn-olive:hover { background-color: #3d4a37; }
        .text-olive { color: #506049; }
    </style>
</head>
<body>

    <nav class="border-b border-[#e3e3e0] bg-white px-6 py-4 flex justify-between items-center">
        <span class="text-2xl font-bold font-serif-thrift tracking-tight">ThriftKu</span>
        <div class="flex items-center gap-6 text-sm font-medium text-gray-600">
            <a href="#" class="hover:text-black">Riwayat Pesanan</a>
            <a href="/login" class="flex items-center gap-1 hover:text-black">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                <span class="bg-[#506049] text-white text-xs w-4 h-4 rounded-full flex items-center justify-center font-bold">0</span>
            </a>
        </div>
    </nav>

    <header class="relative bg-cover bg-center sh-[460px] flex items-center justify-center text-center px-4" 
            style="background-image: linear-gradient(rgba(0, 0, 0, 0.25), rgba(0, 0, 0, 0.25)), url('https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=1200');">
        <div class="max-w-2xl text-white">
            <h1 class="text-4xl md:text-5xl font-bold font-serif-thrift leading-tight">Temukan Pakaian Preloved<br>Berkualitas</h1>
            <p class="mt-4 text-sm md:text-base font-light text-gray-100 max-w-lg mx-auto">
                Kurasi fashion berkelanjutan dengan sentuhan vintage yang abadi. Pilihan terbaik untuk gaya hidup minimalis Anda.
            </p>
            <div class="mt-8 flex justify-center gap-4">
                <a href="#koleksi" class="btn-olive px-6 py-3 rounded-full font-medium text-sm transition shadow-sm">Mulai Jelajah</a>
                <a href="#" class="border border-white hover:bg-white/10 text-white px-6 py-3 rounded-full font-medium text-sm transition">Tentang Kami</a>
            </div>
        </div>
    </header>

    <section id="koleksi" class="py-16 max-w-6xl mx-auto px-4 sm:px-6">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
            <div>
                <h2 class="text-3xl font-bold font-serif-thrift text-[#1b1c1c]">
                    <?php if($kategoriAktif == 'Baju'): ?> Koleksi Baju 
                    <?php elseif($kategoriAktif == 'Celana'): ?> Koleksi Celana
                    <?php elseif($kategoriAktif == 'Pria'): ?> Koleksi Pria
                    <?php elseif($kategoriAktif == 'Wanita'): ?> Koleksi Wanita
                    <?php else: ?> Koleksi Terbaru <?php endif; ?>
                </h2>
                <p class="text-gray-400 text-xs mt-1">
                    <?php if($kategoriAktif != 'all'): ?> Menampilkan item thrift kategori <?php echo e($kategoriAktif); ?> . <?php else: ?> Menampilkan item terpilih untuk bulan ini. <?php endif; ?>
                </p>
            </div>
            
            <div class="flex flex-wrap gap-2 text-xs font-medium">
                <a href="<?php echo e(url('/?kategori=all')); ?>" class="px-5 py-2.5 rounded-full border transition border-[#e3e3e0] <?php echo e($kategoriAktif == 'all' ? 'bg-[#506049] text-white border-[#506049]' : 'bg-white text-gray-700 hover:bg-gray-50'); ?>">Semua</a>
                <a href="<?php echo e(url('/?kategori=Baju')); ?>" class="px-5 py-2.5 rounded-full border transition border-[#e3e3e0] <?php echo e($kategoriAktif == 'Baju' ? 'bg-[#506049] text-white border-[#506049]' : 'bg-white text-gray-700 hover:bg-gray-50'); ?>">Baju</a>
                <a href="<?php echo e(url('/?kategori=Celana')); ?>" class="px-5 py-2.5 rounded-full border transition border-[#e3e3e0] <?php echo e($kategoriAktif == 'Celana' ? 'bg-[#506049] text-white border-[#506049]' : 'bg-white text-gray-700 hover:bg-gray-50'); ?>">Celana</a>
                <a href="<?php echo e(url('/?kategori=Wanita')); ?>" class="px-5 py-2.5 rounded-full border transition border-[#e3e3e0] <?php echo e($kategoriAktif == 'Wanita' ? 'bg-[#506049] text-white border-[#506049]' : 'bg-white text-gray-700 hover:bg-gray-50'); ?>">Wanita</a>
                <a href="<?php echo e(url('/?kategori=Pria')); ?>" class="px-5 py-2.5 rounded-full border transition border-[#e3e3e0] <?php echo e($kategoriAktif == 'Pria' ? 'bg-[#506049] text-white border-[#506049]' : 'bg-white text-gray-700 hover:bg-gray-50'); ?>">Pria</a>
            </div>
        </div>
        
        <!-- Grid Produk -->
<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 justify-items-start w-full">
    <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white border border-[#e3e3e0] rounded-xl overflow-hidden w-full flex flex-col transition hover:-translate-y-1">
            
            <!-- BAGIAN GAMBAR PRODUK -->
            <div class="relative w-full sh-[280px] bg-cover bg-center bg-gray-100" 
                 style="background-image: url('<?php echo e(asset('storage/' . $item->gambar)); ?>');">
                <span class="absolute top-3 left-3 bg-[#506049]/90 text-white text-[10px] font-bold px-2 py-1 rounded tracking-wide uppercase">
                    <?php if($item->kategori == 'Wanita'): ?> RARE FIND <?php else: ?> KONDISI 9/10 <?php endif; ?>
                </span>
            </div>
            
            <!-- SISI KONTEN INFO -->
            <div class="p-4 flex flex-col justify-between flex-1 smin-h-[150px]">   
                <div>
                    <span class="text-[10px] font-bold text-gray-400 tracking-wider uppercase block">SIZE <?php echo e($item->ukuran); ?></span>
                    <h4 class="font-serif-thrift text-[1.05rem] text-[#1b1c1c] font-medium mt-1 leading-tight"><?php echo e($item->nama_produk); ?></h4>
                    <p class="text-[#1b1c1c] text-sm font-semibold mt-2">Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></p>
                </div>
                <a href="<?php echo e(url('/detail/' . $item->id_produk)); ?>" class="block text-center border border-[#1b1c1c] text-[#1b1c1c] text-xs font-semibold rounded py-2 mt-4 hover:bg-[#1b1c1c] hover:text-white transition">
                    Lihat Detail
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full w-full text-center py-16">
            <p class="text-gray-400 italic text-sm">Belum ada produk thrifting tersedia untuk kategori ini.</p>
        </div>
    <?php endif; ?>
</div>
    </section>

</body>
</html><?php /**PATH C:\File Tugas 2025\File Pak Arka Semes 4 Web Lanjut\Trifhku\TrifhKu\Thrifku\resources\views/welcome.blade.php ENDPATH**/ ?>